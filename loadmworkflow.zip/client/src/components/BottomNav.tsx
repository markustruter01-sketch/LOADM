import { Link, useLocation } from "wouter";
import { Home, ClipboardList, Package2, FileCheck, Wrench, GraduationCap } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

export default function BottomNav() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navItems = [
    {
      href: "/",
      label: "Home",
      icon: Home,
      active: location === "/"
    },
    {
      href: "/scenarios",
      label: "Scenarios",
      icon: ClipboardList,
      active: location.startsWith("/scenarios")
    },
    {
      href: "/load-planning",
      label: "Load Plan",
      icon: Package2,
      active: location.startsWith("/load-planning")
    },
    {
      href: "/documents",
      label: "Documents",
      icon: FileCheck,
      active: location === "/documents" || location === "/cargo-manifest" || location.startsWith("/documents/")
    },
    {
      href: "/tools",
      label: "Tools",
      icon: Wrench,
      active: location.startsWith("/tools")
    }
  ];

  return (
    <div className="fixed bottom-0 left-0 w-full border-t border-border bg-card shadow-lg z-50">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div className="flex flex-col items-center justify-center w-full p-2 cursor-pointer">
              <div 
                className={cn(
                  "flex flex-col items-center justify-center",
                  item.active ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <item.icon className="h-5 w-5 mb-1" />
                <span className="text-xs">{item.label}</span>
              </div>
            </div>
          </Link>
        ))}
        
        {/* Add Instructor Portal button if user is authenticated and authorized */}
        {user && (user.isAdmin || user.isSuperAdmin) && (
          <Link href="/instructors-portal">
            <div className="flex flex-col items-center justify-center w-full p-2 cursor-pointer">
              <div 
                className={cn(
                  "flex flex-col items-center justify-center",
                  location.startsWith("/instructors-portal") ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <GraduationCap className="h-5 w-5 mb-1" />
                <span className="text-xs">Instructor</span>
              </div>
            </div>
          </Link>
        )}
      </div>
    </div>
  );
}